jQuery(function ($) {
  var count = 10;
  $('.js-countdown').text(count);

  var countdownInterval = setInterval(function() {
    count--;
    $('.js-countdown').text(count);

    if (count <= 0) {
      clearInterval(countdownInterval);
    }
  }, 1000);
});
