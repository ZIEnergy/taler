jQuery(function ($) {
  
  $('.table__load-more a').on('click', function (e) {
    e.preventDefault();
    
    var tableRows = $(this).parents('.table').find('.table__body .table__tr');
    var hiddenRows = [];
    
    var addRowsHandler = function (row) {
      row.each(function (index, el) {
        if ($(el).is(':hidden')) {
          hiddenRows.push(index);
        }
      });
    };
    
    addRowsHandler(tableRows);
    
    var slicedArray = hiddenRows.slice(0, 10);
    slicedArray.forEach(function (index) {
      $(tableRows[index]).show();
    });
    hiddenRows = [];
    addRowsHandler(tableRows);
    if (!hiddenRows.length) {
      $(this).parent().hide();
    }
  });
  
  $('.table__load-more').each(function () {
    var rowsLength = $(this).siblings('.table__body').find('.table__tr').length;
    if (rowsLength <= 1) {
      $(this).remove();
    }
  });
});
