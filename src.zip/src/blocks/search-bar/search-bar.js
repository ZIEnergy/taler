jQuery(function ($) {
  
  if ($('.search-bar__input').length && $('.search-bar__input').val()) {
    $(this).find('.search-bar__delete').addClass('is-active');
  }
  
  $('.search-bar__input').on('keyup', function (e) {
    var val = e.target.value;
    if (val) {
      $(this).parents('.search-bar__field').find('.search-bar__delete').addClass('is-active');
      return;
    }
    $(this).parents('.search-bar__field').find('.search-bar__delete').removeClass('is-active');
  });
  
  $('.search-bar__delete').on('click', function (e) {
    e.preventDefault();
    
    var that = $(this);
    
    $(this).parents('.search-bar__field').find('.search-bar__input').val('');
    setTimeout(function () {
      that.removeClass('is-active');
    }, 300);
  })

  if ($('.js-button-anim').length) {
    $('.js-button-anim').each(function () {
      let layout = new rive.Layout({
        fit: rive.Fit.Cover,
      });
      const r = new rive.Rive({
        src: "./public/riv_animations/button_upd.riv",
        // OR the path to a discoverable and public Rive asset
        // src: '/public/example.riv',
        canvas: $(this)[0],
        layout: layout,
        autoplay: true,
        /*onLoad: () => {
          r.resizeDrawingSurfaceToCanvas();
        },*/
      });
    });
  }
  
});
