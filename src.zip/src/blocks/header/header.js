$(window).scroll(function() {

  const mq = window.matchMedia( "(min-width: 767.98px)" );
  const mqMob = window.matchMedia( "(max-width: 768px)" );

  if (mq.matches) {
    var elementTarget = $('.js-sticky')[0];
    if (elementTarget.getBoundingClientRect().y < 0) {
      $('.header').addClass('is-fixed');
    } else {
      $('.header').removeClass('is-fixed');
    }
  }

  if (mqMob.matches) {
    var elementTarget = $('.js-sticky')[0];
    if (elementTarget.getBoundingClientRect().y < 0) {
      $('.header__mob').addClass('is-fixed');
    } else {
      $('.header__mob').removeClass('is-fixed');
    }
  }
  
});
